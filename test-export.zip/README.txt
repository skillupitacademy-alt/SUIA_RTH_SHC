Analytical Inteligence Export - ZIP Bundle
Export Version: 2.0
Generated: 2026-03-13T07:58:28.809Z

This ZIP contains 14 files for deep analytical review:

- raw_attempts.csv: The fundamental fact table of every question answered.
- L1 through L12: Multi-dimensional aggregations (Domain down to Skill-by-Topic).
- historical_progress.csv: Longitudinal performance tracking across sessions.
- guidance_signals.csv: AI-derived recommendations and critical gap alerts.

Usage: Import these files into Excel or PowerBI for advanced visualization.